var jsonData = {
    "result":true,
    "msg":"",
    "selectData":{

    },
    "tableHover":[

    ],
    "data":{
        "甘铁生":9,
        "朱喜亮":9,
        "谭平山":7,
        "林君莲":7,
        "范长江":6,
        "章汉夫":5,
        "黄强辉":5,
        "林莽":3,
        "马宏宇":2,
        "谢大海":2,
        "高大山":0,
        "彭万里":0
    },
    "formData":{

    },
    "gridData":{
    
    }
}
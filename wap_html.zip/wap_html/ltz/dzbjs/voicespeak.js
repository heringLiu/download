$(function(){
	$("#speakButton").attr("speak_status","朗读");
	$("#speakButton").css("background-image","url('../../img/start_speak.png')");
	
	$("#speakButton").click(function(){
		var $this = $(this);
		if (isAndriod) {
			if ("朗读" == $this.attr("speak_status")) {
				var str = $("#nr").text();
				window.webview.startSpeaking(str);
				$this.attr("speak_status","暂停");
				$this.css("background-image","url('../../img/stop_speak.png') ");
			} else if ("暂停" == $this.attr("speak_status")) {
				window.webview.pauseSpeaking();
				$this.attr("speak_status","继续");
				$this.css("background-image","url('../../img/start_speak.png') ");
			} else if ("继续" == $this.attr("speak_status")) {
				window.webview.resumeSpeaking();
				$this.attr("speak_status","暂停");
				$this.css("background-image","url('../../img/stop_speak.png') ");
			}
            } else if (isIphone) {
                if ("朗读" == $this.attr("speak_status")) {
                    var str = $("#nr").text();
                    window.location.href = 'obj-c://speak/"str":"'+str+'"';
                    $this.attr("speak_status","暂停");
                    $this.css("background-image","url('../../img/stop_speak.png') ");
                } else if ("暂停" == $this.attr("speak_status")) {
                    window.location.href = 'obj-c://pause/';
                    $this.attr("speak_status","继续");
                    $this.css("background-image","url('../../img/start_speak.png') ");
                } else if ("继续" == $this.attr("speak_status")) {
                    window.location.href = 'obj-c://resume/';
                    $this.attr("speak_status","暂停");
                    $this.css("background-image","url('../../img/stop_speak.png') ");
                }
            }
	});
});

function onSpeakCompleted(){
	$("#speakButton").attr("speak_status","朗读");
	$("#speakButton").css("background-image","url('../../img/start_speak.png') ");
}

